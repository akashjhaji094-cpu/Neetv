import { useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { supabase } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { useQuery } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { Loader2 } from "lucide-react";
import {
  LayoutGrid, CheckCircle2, Circle, MinusCircle, Target,
  Atom, FlaskConical, Dna, TrendingUp, BookOpen
} from "lucide-react";
import { neetPlanner } from "@/data/neetPlanner";

interface ChapterProgress {
  chapterId: string;
  chapterName: string;
  subjectId: string;
  subjectName: string;
  totalQuestions: number;
  attemptedQuestions: number;
  correctQuestions: number;
  accuracyPct: number;
  status: "completed" | "in_progress" | "not_started";
}

const ChapterTracker = () => {
  const { user } = useAuth();

  const { data: allSubjects } = useQuery({
    queryKey: ["subjects"],
    queryFn: async () => {
      const { data } = await supabase.from("subjects").select("*");
      return data || [];
    },
  });

  const { data: allChapters } = useQuery({
    queryKey: ["chapters"],
    queryFn: async () => {
      const { data } = await supabase.from("chapters").select("*");
      return data || [];
    },
  });

  const { data: attemptData, isLoading } = useQuery({
    queryKey: ["chapter-tracker-data", user?.id],
    queryFn: async () => {
      if (!user) return null;
      // Get all attempts with their answers
      const { data: attempts } = await supabase
        .from("attempts")
        .select("id, type")
        .eq("user_id", user.id)
        .not("finished_at", "is", null);
      if (!attempts || attempts.length === 0) return [];

      const attemptIds = attempts.map((a) => a.id);
      const allAnswers: any[] = [];
      for (let i = 0; i < attemptIds.length; i += 100) {
        const { data } = await supabase
          .from("attempt_answers")
          .select("question_id, is_correct, questions(chapter_id, subject_id)")
          .in("attempt_id", attemptIds.slice(i, i + 100));
        if (data) allAnswers.push(...data);
      }
      return allAnswers;
    },
    enabled: !!user,
  });

  const subjectConfig: Record<string, { icon: typeof Atom; color: string; gradient: string }> = {
    physics: { icon: Atom, color: "text-blue-600", gradient: "from-blue-500 to-indigo-600" },
    chemistry: { icon: FlaskConical, color: "text-green-600", gradient: "from-green-500 to-teal-600" },
    biology: { icon: Dna, color: "text-purple-600", gradient: "from-purple-500 to-pink-600" },
  };

  const chapterProgress: ChapterProgress[] = useMemo(() => {
    if (!allSubjects || !allChapters) return [];

    const progressList: ChapterProgress[] = [];

    neetPlanner.forEach((subject) => {
      const dbSubject = allSubjects.find((s) => s.slug === subject.id);
      if (!dbSubject) return;

      subject.chapters.forEach((chapter) => {
        const dbChapter = allChapters.find((c) => c.slug === chapter.id && c.subject_id === dbSubject.id);
        if (!dbChapter) return;

        // Filter answers for this chapter
        const chapterAnswers = (attemptData || []).filter(
          (a: any) => a.questions?.chapter_id === dbChapter.id
        );

        const uniqueQuestionIds = new Set(chapterAnswers.map((a: any) => a.question_id));
        const attemptedCount = uniqueQuestionIds.size;
        const correctCount = chapterAnswers.filter((a: any) => a.is_correct === true).length;

        // Calculate accuracy based on attempts (not unique questions)
        const totalAttempts = chapterAnswers.length;
        const accuracy = totalAttempts > 0 ? Math.round((correctCount / totalAttempts) * 100) : 0;

        let status: "completed" | "in_progress" | "not_started" = "not_started";
        if (attemptedCount >= 5 && accuracy >= 70) status = "completed";
        else if (attemptedCount > 0) status = "in_progress";

        progressList.push({
          chapterId: dbChapter.id,
          chapterName: chapter.name,
          subjectId: subject.id,
          subjectName: subject.name,
          totalQuestions: 0,
          attemptedQuestions: attemptedCount,
          correctQuestions: correctCount,
          accuracyPct: accuracy,
          status,
        });
      });
    });

    return progressList;
  }, [allSubjects, allChapters, attemptData]);

  const bySubject = useMemo(() => {
    const map = new Map<string, ChapterProgress[]>();
    chapterProgress.forEach((c) => {
      const arr = map.get(c.subjectId) || [];
      arr.push(c);
      map.set(c.subjectId, arr);
    });
    return Array.from(map.entries());
  }, [chapterProgress]);

  const getSubjectSummary = (subjectId: string) => {
    const chapters = chapterProgress.filter((c) => c.subjectId === subjectId);
    const total = chapters.length;
    const completed = chapters.filter((c) => c.status === "completed").length;
    const inProgress = chapters.filter((c) => c.status === "in_progress").length;
    const notStarted = chapters.filter((c) => c.status === "not_started").length;
    const overallAccuracy = chapters.filter((c) => c.attemptedQuestions > 0).length > 0
      ? Math.round(
          chapters
            .filter((c) => c.attemptedQuestions > 0)
            .reduce((s, c) => s + c.accuracyPct, 0) /
            chapters.filter((c) => c.attemptedQuestions > 0).length
        )
      : 0;
    return { total, completed, inProgress, notStarted, overallAccuracy };
  };

  if (!user) {
    return (
      <DashboardLayout>
        <div className="p-4 lg:p-6 max-w-5xl">
          <Card className="p-8 text-center">
            <LayoutGrid className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
            <p className="font-medium">Sign in to track chapter progress</p>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-4 lg:p-6 space-y-6 max-w-5xl">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-primary/10 rounded-xl">
            <LayoutGrid className="h-7 w-7 text-primary" />
          </div>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">Chapter Tracker</h1>
            <p className="text-muted-foreground">Visual progress across all NEET chapters</p>
          </div>
        </div>

        {/* Overall Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <BookOpen className="h-5 w-5 mx-auto mb-1 text-primary" />
              <p className="text-2xl font-bold">{chapterProgress.length}</p>
              <p className="text-xs text-muted-foreground">Total Chapters</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <CheckCircle2 className="h-5 w-5 mx-auto mb-1 text-green-500" />
              <p className="text-2xl font-bold text-green-600">
                {chapterProgress.filter((c) => c.status === "completed").length}
              </p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="h-5 w-5 mx-auto mb-1 text-amber-500" />
              <p className="text-2xl font-bold text-amber-600">
                {chapterProgress.filter((c) => c.status === "in_progress").length}
              </p>
              <p className="text-xs text-muted-foreground">In Progress</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <Target className="h-5 w-5 mx-auto mb-1 text-blue-500" />
              <p className="text-2xl font-bold text-blue-600">
                {chapterProgress.filter((c) => c.attemptedQuestions > 0).length > 0
                  ? Math.round(
                      chapterProgress
                        .filter((c) => c.attemptedQuestions > 0)
                        .reduce((s, c) => s + c.accuracyPct, 0) /
                        chapterProgress.filter((c) => c.attemptedQuestions > 0).length
                    )
                  : 0}%
              </p>
              <p className="text-xs text-muted-foreground">Overall Accuracy</p>
            </CardContent>
          </Card>
        </div>

        {/* Overall progress bar */}
        {chapterProgress.length > 0 && (
          <Card>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-sm font-medium">Overall Progress</span>
                <span className="text-sm font-bold text-primary">
                  {chapterProgress.filter((c) => c.status === "completed").length}/{chapterProgress.length} chapters
                </span>
              </div>
              <div className="h-4 rounded-full bg-muted overflow-hidden flex">
                <div
                  className="h-full bg-green-500 transition-all"
                  style={{
                    width: `${(chapterProgress.filter((c) => c.status === "completed").length / chapterProgress.length) * 100}%`,
                  }}
                />
                <div
                  className="h-full bg-amber-400 transition-all"
                  style={{
                    width: `${(chapterProgress.filter((c) => c.status === "in_progress").length / chapterProgress.length) * 100}%`,
                  }}
                />
              </div>
              <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                <span className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-green-500" /> Completed
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-amber-400" /> In Progress
                </span>
                <span className="flex items-center gap-1">
                  <div className="w-2.5 h-2.5 rounded-full bg-muted border" /> Not Started
                </span>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Loading */}
        {isLoading ? (
          <Card>
            <CardContent className="p-10 text-center text-muted-foreground flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" /> Analyzing your progress...
            </CardContent>
          </Card>
        ) : (
          /* Subject Tabs */
          <Tabs defaultValue="physics" className="space-y-4">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="physics" className="gap-2">
                <Atom className="h-4 w-4" /> Physics
              </TabsTrigger>
              <TabsTrigger value="chemistry" className="gap-2">
                <FlaskConical className="h-4 w-4" /> Chemistry
              </TabsTrigger>
              <TabsTrigger value="biology" className="gap-2">
                <Dna className="h-4 w-4" /> Biology
              </TabsTrigger>
            </TabsList>

            {(["physics", "chemistry", "biology"] as const).map((subjectId) => {
              const chapters = chapterProgress.filter((c) => c.subjectId === subjectId);
              const summary = getSubjectSummary(subjectId);
              const config = subjectConfig[subjectId];
              const Icon = config?.icon || BookOpen;

              return (
                <TabsContent key={subjectId} value={subjectId} className="space-y-4">
                  {/* Subject Summary Card */}
                  <Card className="overflow-hidden">
                    <div className={`bg-gradient-to-r ${config.gradient} p-4 text-white`}>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          <Icon className="h-6 w-6" />
                          <div>
                            <h3 className="text-lg font-bold capitalize">{subjectId}</h3>
                            <p className="text-white/80 text-sm">
                              {summary.completed}/{summary.total} chapters completed
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="text-2xl font-black">{summary.overallAccuracy}%</p>
                          <p className="text-xs text-white/80">Avg Accuracy</p>
                        </div>
                      </div>
                    </div>
                    <CardContent className="p-4">
                      <div className="h-3 rounded-full bg-muted overflow-hidden flex">
                        <div
                          className="h-full bg-green-500 transition-all"
                          style={{ width: `${(summary.completed / summary.total) * 100}%` }}
                        />
                        <div
                          className="h-full bg-amber-400 transition-all"
                          style={{ width: `${(summary.inProgress / summary.total) * 100}%` }}
                        />
                      </div>
                      <div className="flex gap-4 mt-2 text-xs text-muted-foreground">
                        <span>{summary.completed} completed</span>
                        <span>{summary.inProgress} in progress</span>
                        <span>{summary.notStarted} not started</span>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Chapter Grid */}
                  <div className="grid grid-cols-1 gap-2">
                    {chapters.map((ch) => (
                      <Card
                        key={ch.chapterId}
                        className={`transition-all hover:shadow-md ${
                          ch.status === "completed"
                            ? "border-green-200 dark:border-green-800"
                            : ch.status === "in_progress"
                            ? "border-amber-200 dark:border-amber-800"
                            : ""
                        }`}
                      >
                        <CardContent className="p-3 flex items-center gap-3">
                          {/* Status Icon */}
                          <div className="flex-shrink-0">
                            {ch.status === "completed" ? (
                              <div className="w-8 h-8 rounded-full bg-green-100 dark:bg-green-900/50 flex items-center justify-center">
                                <CheckCircle2 className="h-5 w-5 text-green-600" />
                              </div>
                            ) : ch.status === "in_progress" ? (
                              <div className="w-8 h-8 rounded-full bg-amber-100 dark:bg-amber-900/50 flex items-center justify-center">
                                <TrendingUp className="h-5 w-5 text-amber-600" />
                              </div>
                            ) : (
                              <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center">
                                <Circle className="h-5 w-5 text-muted-foreground" />
                              </div>
                            )}
                          </div>

                          {/* Info */}
                          <div className="flex-1 min-w-0">
                            <p className="font-medium text-sm truncate">{ch.chapterName}</p>
                            <div className="flex items-center gap-2 text-xs text-muted-foreground">
                              {ch.attemptedQuestions > 0 ? (
                                <>
                                  <span>{ch.attemptedQuestions} attempted</span>
                                  <span>•</span>
                                  <span className={ch.accuracyPct >= 70 ? "text-green-600" : ch.accuracyPct >= 40 ? "text-amber-600" : "text-red-600"}>
                                    {ch.accuracyPct}% accuracy
                                  </span>
                                </>
                              ) : (
                                <span className="flex items-center gap-1">
                                  <MinusCircle className="h-3 w-3" /> Not started yet
                                </span>
                              )}
                            </div>
                          </div>

                          {/* Accuracy bar */}
                          {ch.attemptedQuestions > 0 && (
                            <div className="w-24 flex-shrink-0 hidden sm:block">
                              <Progress value={ch.accuracyPct} className="h-2" />
                            </div>
                          )}

                          {/* Badge */}
                          <Badge
                            className={`flex-shrink-0 text-[10px] ${
                              ch.status === "completed"
                                ? "bg-green-100 text-green-700 dark:bg-green-900 dark:text-green-300 hover:bg-green-100"
                                : ch.status === "in_progress"
                                ? "bg-amber-100 text-amber-700 dark:bg-amber-900 dark:text-amber-300 hover:bg-amber-100"
                                : "bg-muted text-muted-foreground hover:bg-muted"
                            }`}
                          >
                            {ch.status === "completed" ? "Done" : ch.status === "in_progress" ? "WIP" : "Start"}
                          </Badge>
                        </CardContent>
                      </Card>
                    ))}
                  </div>

                  {chapters.length === 0 && (
                    <Card>
                      <CardContent className="p-8 text-center text-muted-foreground">
                        No chapters found for this subject.
                      </CardContent>
                    </Card>
                  )}
                </TabsContent>
              );
            })}
          </Tabs>
        )}
      </div>
    </DashboardLayout>
  );
};

export default ChapterTracker;
