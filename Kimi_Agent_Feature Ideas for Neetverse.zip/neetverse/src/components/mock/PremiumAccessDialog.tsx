import { useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Key, Download } from "lucide-react";
import { Card } from "@/components/ui/card";

interface PremiumAccessDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onAccessGranted: () => void;
}

interface Planner {
  id: string;
  title: string;
  file_url: string;
  created_at: string;
}

interface PremiumTest {
  id: string;
  title: string;
  description: string | null;
  file_url: string;
  created_at: string;
}

export const PremiumAccessDialog = ({
  open,
  onOpenChange,
  onAccessGranted,
}: PremiumAccessDialogProps) => {
  const [accessKey, setAccessKey] = useState("");
  const [loading, setLoading] = useState(false);
  const [hasAccess, setHasAccess] = useState(false);
  const [planners, setPlanners] = useState<Planner[]>([]);
  const [premiumTests, setPremiumTests] = useState<PremiumTest[]>([]);

  const verifyAccessKey = async () => {
    if (!accessKey.trim()) {
      toast.error("Please enter an access key");
      return;
    }

    setLoading(true);

    const { data: authData } = await supabase.auth.getUser();
    if (!authData.user) {
      toast.error("You must be logged in");
      setLoading(false);
      return;
    }

    // Verify access key
    const { data: keyData, error: keyError } = await supabase
      .from("premium_access_keys")
      .select("*")
      .eq("access_key", accessKey)
      .eq("user_id", authData.user.id)
      .eq("is_active", true)
      .single();

    if (keyError || !keyData) {
      toast.error("Invalid or inactive access key");
      setLoading(false);
      return;
    }

    // Fetch premium tests (specific to this key OR available to all keys)
    const { data: testsData, error: testsError } = await supabase
      .from("premium_tests")
      .select("*")
      .or(`access_key.eq.${accessKey},access_key.is.null`)
      .order("created_at", { ascending: false });

    if (testsError) {
      console.error(testsError);
    }

    // Fetch all planners (public, no key needed)
    const { data: plannersData, error: plannersError } = await supabase
      .from("premium_planners")
      .select("*")
      .order("created_at", { ascending: false });

    if (plannersError) {
      console.error(plannersError);
    }

    setHasAccess(true);
    setPremiumTests(testsData || []);
    setPlanners(plannersData || []);
    toast.success("Access verified! You can now access premium tests.");
    setLoading(false);
  };


  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Key className="h-5 w-5 text-primary" />
            Premium Test Access
          </DialogTitle>
          <DialogDescription className="space-y-2">
            <p>Enter your premium access key to unlock exclusive test content.</p>
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-3 text-sm">
              <p className="font-semibold text-yellow-800 dark:text-yellow-200">
                💰 Get Premium Access for only ₹399!
              </p>
              <p className="text-yellow-700 dark:text-yellow-300 mt-1">
                Contact on Telegram: <a href="https://t.me/akaxxh" target="_blank" rel="noopener noreferrer" className="underline font-medium">@akaxxh</a>
              </p>
            </div>
          </DialogDescription>
        </DialogHeader>

        {!hasAccess ? (
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="access-key">Access Key</Label>
              <Input
                id="access-key"
                value={accessKey}
                onChange={(e) => setAccessKey(e.target.value)}
                placeholder="PRM-XXXX-XXXXXXX"
                className="font-mono"
              />
            </div>
            <Button onClick={verifyAccessKey} disabled={loading} className="w-full">
              <Key className="h-4 w-4 mr-2" />
              Verify Access
            </Button>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
              <p className="text-sm text-green-800 dark:text-green-200 font-medium">
                ✓ Access Verified Successfully
              </p>
              <p className="text-xs text-green-700 dark:text-green-300 mt-1">
                📚 Based on 20 Years PYQs + PW, Allen, Akash questions
              </p>
            </div>

            {/* Premium Tests Section */}
            {premiumTests.length > 0 && (
              <div className="space-y-2">
                <Label className="text-base font-semibold">Premium Test PDFs</Label>
                <div className="space-y-2 max-h-[250px] overflow-y-auto">
                  {premiumTests.map((test) => (
                    <Card key={test.id} className="p-4 bg-gradient-to-r from-yellow-50 to-orange-50 dark:from-yellow-900/10 dark:to-orange-900/10 border-yellow-200 dark:border-yellow-800">
                      <div className="flex items-center justify-between gap-3">
                        <div className="flex-1">
                          <h4 className="font-semibold text-sm">{test.title}</h4>
                          {test.description && (
                            <p className="text-xs text-muted-foreground mt-1">{test.description}</p>
                          )}
                          <p className="text-xs text-muted-foreground mt-1">
                            {new Date(test.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          variant="default"
                          size="sm"
                          className="bg-yellow-500 hover:bg-yellow-600 text-white shrink-0"
                          onClick={() => window.open(test.file_url, "_blank")}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {/* Study Planners Section */}
            {planners.length > 0 && (
              <div className="space-y-2">
                <Label className="text-base font-semibold">Study Planners</Label>
                <div className="space-y-2 max-h-[200px] overflow-y-auto">
                  {planners.map((planner) => (
                    <Card key={planner.id} className="p-3 border-border">
                      <div className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium text-sm">{planner.title}</h4>
                          <p className="text-xs text-muted-foreground">
                            {new Date(planner.created_at).toLocaleDateString()}
                          </p>
                        </div>
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => window.open(planner.file_url, "_blank")}
                        >
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      </div>
                    </Card>
                  ))}
                </div>
              </div>
            )}

            {premiumTests.length === 0 && planners.length === 0 && (
              <div className="bg-muted rounded-lg p-4 text-center text-sm text-muted-foreground">
                No materials available yet. Contact admin for more info.
              </div>
            )}
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
