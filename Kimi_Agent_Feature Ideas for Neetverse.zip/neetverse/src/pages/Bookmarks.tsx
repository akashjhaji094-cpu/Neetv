import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger,
} from "@/components/ui/dialog";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { supabase, Question } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useToast } from "@/hooks/use-toast";
import {
  Bookmark, BookmarkX, Search, BookOpen, Tag, Loader2,
  ChevronLeft, ChevronRight, Sparkles, StickyNote, Filter
} from "lucide-react";

interface BookmarkedQuestion {
  id: string;
  question_id: string;
  note: string | null;
  created_at: string;
  question?: Question & { subjects?: { name: string } | null; chapters?: { name: string } | null };
}

const PAGE_SIZE = 10;
const LETTERS = ["A", "B", "C", "D"];

const Bookmarks = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [search, setSearch] = useState("");
  const [subjectFilter, setSubjectFilter] = useState("all");
  const [page, setPage] = useState(1);
  const [expandedQuestion, setExpandedQuestion] = useState<string | null>(null);
  const [editNote, setEditNote] = useState("");
  const [editingId, setEditingId] = useState<string | null>(null);

  const { data: bookmarks, isLoading } = useQuery({
    queryKey: ["bookmarked-questions", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data, error } = await supabase
        .from("bookmarked_questions")
        .select("*, question:questions(*, subjects(name), chapters(name))")
        .eq("user_id", user.id)
        .order("created_at", { ascending: false });
      if (error) throw error;
      return (data || []) as BookmarkedQuestion[];
    },
    enabled: !!user,
  });

  const subjects = useMemo(() => {
    const set = new Set<string>();
    bookmarks?.forEach((b) => {
      const name = (b.question?.subjects as any)?.name;
      if (name) set.add(name);
    });
    return Array.from(set).sort();
  }, [bookmarks]);

  const filtered = useMemo(() => {
    return (bookmarks || []).filter((b) => {
      const q = b.question;
      if (!q) return false;
      if (subjectFilter !== "all") {
        const subjName = (q.subjects as any)?.name;
        if (subjName !== subjectFilter) return false;
      }
      if (search.trim()) {
        const qtext = q.question_text?.toLowerCase() || "";
        const chapName = (q.chapters as any)?.name?.toLowerCase() || "";
        const subjName = (q.subjects as any)?.name?.toLowerCase() || "";
        const term = search.toLowerCase();
        if (!qtext.includes(term) && !chapName.includes(term) && !subjName.includes(term)) return false;
      }
      return true;
    });
  }, [bookmarks, subjectFilter, search]);

  const totalPages = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const pageItems = filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE);

  // Remove bookmark
  const removeMutation = useMutation({
    mutationFn: async (bookmarkId: string) => {
      const { error } = await supabase.from("bookmarked_questions").delete().eq("id", bookmarkId);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bookmarked-questions"] });
      toast({ title: "Bookmark removed" });
    },
  });

  // Update note
  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, note }: { id: string; note: string }) => {
      const { error } = await supabase.from("bookmarked_questions").update({ note }).eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["bookmarked-questions"] });
      setEditingId(null);
      toast({ title: "Note saved" });
    },
  });

  const startEditingNote = (bm: BookmarkedQuestion) => {
    setEditingId(bm.id);
    setEditNote(bm.note || "");
  };

  const saveNote = () => {
    if (editingId) {
      updateNoteMutation.mutate({ id: editingId, note: editNote });
    }
  };

  if (!user) {
    return (
      <DashboardLayout>
        <div className="p-4 lg:p-6 max-w-4xl">
          <Card className="p-8 text-center">
            <Bookmark className="h-12 w-12 mx-auto text-muted-foreground mb-3" />
            <p className="font-medium">Sign in to view your bookmarks</p>
            <p className="text-sm text-muted-foreground">Save important questions while practicing</p>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return (
    <DashboardLayout>
      <div className="p-4 lg:p-6 space-y-6 max-w-5xl">
        {/* Header */}
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-primary/10 rounded-xl">
            <Bookmark className="h-7 w-7 text-primary fill-primary" />
          </div>
          <div>
            <h1 className="text-2xl lg:text-3xl font-bold">Bookmarked Questions</h1>
            <p className="text-muted-foreground">Questions you saved for quick revision</p>
          </div>
          <div className="ml-auto">
            <Badge variant="secondary" className="text-sm">
              {filtered.length} saved
            </Badge>
          </div>
        </div>

        {/* Filters */}
        <Card>
          <CardContent className="p-4 flex flex-col sm:flex-row gap-3">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search question, chapter, subject..."
                className="pl-9"
                value={search}
                onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              />
            </div>
            <Select value={subjectFilter} onValueChange={(v) => { setSubjectFilter(v); setPage(1); }}>
              <SelectTrigger className="w-full sm:w-44">
                <Filter className="h-4 w-4 mr-1" />
                <SelectValue placeholder="Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                {subjects.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </CardContent>
        </Card>

        {/* List */}
        {isLoading ? (
          <Card>
            <CardContent className="p-10 text-center text-muted-foreground flex items-center justify-center gap-2">
              <Loader2 className="h-5 w-5 animate-spin" /> Loading bookmarks...
            </CardContent>
          </Card>
        ) : filtered.length === 0 ? (
          <Card>
            <CardContent className="p-10 text-center text-muted-foreground">
              <Bookmark className="h-12 w-12 mx-auto mb-3 opacity-30" />
              {bookmarks?.length === 0 ? (
                <>
                  <p className="font-medium">No bookmarks yet</p>
                  <p className="text-sm mt-1">
                    While practicing, bookmark tricky questions to review them here.
                  </p>
                </>
              ) : (
                <p>No bookmarks match your filters.</p>
              )}
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-3">
            {pageItems.map((bm) => {
              const q = bm.question;
              if (!q) return null;
              const isExpanded = expandedQuestion === bm.id;
              const subjectName = (q.subjects as any)?.name || "Unknown";
              const chapterName = (q.chapters as any)?.name || "Unknown";

              return (
                <Card key={bm.id} className={`transition-all ${isExpanded ? "ring-1 ring-primary" : ""}`}>
                  <CardContent className="p-4">
                    {/* Tags */}
                    <div className="flex items-center gap-2 mb-2 flex-wrap">
                      <Badge variant="outline" className="text-[10px]">{subjectName}</Badge>
                      <Badge variant="secondary" className="text-[10px]">{chapterName}</Badge>
                      {bm.note && (
                        <Badge className="text-[10px] gap-1 bg-amber-500/10 text-amber-600 border-amber-200">
                          <StickyNote className="h-3 w-3" /> Note
                        </Badge>
                      )}
                    </div>

                    {/* Question preview */}
                    <div
                      className={`text-sm ${isExpanded ? "" : "line-clamp-2"}`}
                      dangerouslySetInnerHTML={{ __html: q.question_text }}
                    />

                    {/* Expanded: options + explanation */}
                    {isExpanded && (
                      <div className="mt-4 space-y-3">
                        {q.options?.map((opt: string, i: number) => (
                          <div
                            key={i}
                            className={`p-3 rounded-lg border text-sm ${
                              i === q.correct_option_index
                                ? "border-green-500 bg-green-50 dark:bg-green-950/30"
                                : "border-border bg-muted/30"
                            }`}
                          >
                            <span className="font-bold mr-2">{LETTERS[i]}.</span>
                            <span dangerouslySetInnerHTML={{ __html: opt }} />
                            {i === q.correct_option_index && (
                              <Badge className="ml-2 bg-green-600 text-[10px]">Correct</Badge>
                            )}
                          </div>
                        ))}
                        {q.explanation && (
                          <div className="p-3 rounded-lg bg-blue-50 dark:bg-blue-950/30 border border-blue-200 dark:border-blue-800">
                            <p className="text-xs font-semibold text-blue-700 dark:text-blue-300 mb-1 flex items-center gap-1">
                              <Sparkles className="h-3 w-3" /> Explanation
                            </p>
                            <p className="text-sm text-blue-800 dark:text-blue-200" dangerouslySetInnerHTML={{ __html: q.explanation }} />
                          </div>
                        )}

                        {/* Note editor */}
                        {editingId === bm.id ? (
                          <div className="space-y-2">
                            <Textarea
                              placeholder="Add your note..."
                              value={editNote}
                              onChange={(e) => setEditNote(e.target.value)}
                              rows={3}
                            />
                            <div className="flex gap-2">
                              <Button size="sm" onClick={saveNote} disabled={updateNoteMutation.isPending}>
                                Save Note
                              </Button>
                              <Button size="sm" variant="ghost" onClick={() => setEditingId(null)}>
                                Cancel
                              </Button>
                            </div>
                          </div>
                        ) : bm.note ? (
                          <div className="p-3 rounded-lg bg-amber-50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-800">
                            <p className="text-xs font-semibold text-amber-700 dark:text-amber-300 mb-1 flex items-center gap-1">
                              <StickyNote className="h-3 w-3" /> Your Note
                            </p>
                            <p className="text-sm">{bm.note}</p>
                          </div>
                        ) : null}
                      </div>
                    )}

                    {/* Actions */}
                    <div className="flex items-center gap-2 mt-3 pt-3 border-t">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => setExpandedQuestion(isExpanded ? null : bm.id)}
                      >
                        <BookOpen className="h-4 w-4 mr-1" />
                        {isExpanded ? "Collapse" : "View Full"}
                      </Button>
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => startEditingNote(bm)}
                      >
                        <Tag className="h-4 w-4 mr-1" />
                        {bm.note ? "Edit Note" : "Add Note"}
                      </Button>
                      <div className="ml-auto">
                        <Button
                          variant="ghost"
                          size="sm"
                          className="text-destructive hover:text-destructive"
                          onClick={() => removeMutation.mutate(bm.id)}
                          disabled={removeMutation.isPending}
                        >
                          <BookmarkX className="h-4 w-4 mr-1" /> Remove
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}

        {/* Pagination */}
        {filtered.length > PAGE_SIZE && (
          <div className="flex items-center justify-between">
            <p className="text-sm text-muted-foreground">
              Showing {(page - 1) * PAGE_SIZE + 1}–{Math.min(page * PAGE_SIZE, filtered.length)} of {filtered.length}
            </p>
            <div className="flex gap-2">
              <Button variant="outline" size="sm" disabled={page === 1} onClick={() => setPage((p) => p - 1)}>
                <ChevronLeft className="h-4 w-4" /> Prev
              </Button>
              <Button variant="outline" size="sm" disabled={page === totalPages} onClick={() => setPage((p) => p + 1)}>
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Bookmarks;
