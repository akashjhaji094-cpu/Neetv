-- Bookmarked Questions table for students to save tricky questions
CREATE TABLE IF NOT EXISTS bookmarked_questions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  question_id uuid NOT NULL REFERENCES questions(id) ON DELETE CASCADE,
  note text DEFAULT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(user_id, question_id)
);

-- Index for fast lookups
CREATE INDEX IF NOT EXISTS idx_bookmarked_questions_user_id ON bookmarked_questions(user_id);
CREATE INDEX IF NOT EXISTS idx_bookmarked_questions_question_id ON bookmarked_questions(question_id);

-- RLS policies
ALTER TABLE bookmarked_questions ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view own bookmarks"
  ON bookmarked_questions FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own bookmarks"
  ON bookmarked_questions FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own bookmarks"
  ON bookmarked_questions FOR DELETE
  USING (auth.uid() = user_id);
