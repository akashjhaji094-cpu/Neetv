import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { supabase, Question } from "@/lib/supabase";
import { useAuth } from "@/hooks/useAuth";
import { useQuery, useMutation } from "@tanstack/react-query";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { useToast } from "@/hooks/use-toast";
import {
  Trophy, Timer, Flame, ChevronRight, ChevronLeft, CheckCircle2,
  XCircle, MinusCircle, Sparkles, RotateCcw, BarChart3, Calendar
} from "lucide-react";
import { format } from "date-fns";

interface DailyChallenge {
  id: string;
  challenge_date: string;
  question_ids: string[];
  title: string;
  description: string;
}

interface ChallengeAttempt {
  id: string;
  challenge_id: string;
  score: number;
  correct_count: number;
  wrong_count: number;
  unattempted_count: number;
  time_taken_seconds: number;
  completed_at: string;
}

const LETTERS = ["A", "B", "C", "D"];

const DailyChallenge = () => {
  const { user } = useAuth();
  const { toast } = useToast();
  const [view, setView] = useState<"landing" | "quiz" | "result">("landing");
  const [questions, setQuestions] = useState<Question[]>([]);
  const [answers, setAnswers] = useState<Record<string, number | null>>({});
  const [currentIdx, setCurrentIdx] = useState(0);
  const [startTime, setStartTime] = useState(0);
  const [elapsedTime, setElapsedTime] = useState(0);
  const [resultData, setResultData] = useState<{
    score: number; correct: number; wrong: number; skipped: number; timeSeconds: number;
  } | null>(null);

  // Timer
  useEffect(() => {
    if (view !== "quiz") return;
    const interval = setInterval(() => {
      setElapsedTime(Math.floor((Date.now() - startTime) / 1000));
    }, 1000);
    return () => clearInterval(interval);
  }, [view, startTime]);

  // Fetch today's challenge
  const { data: todayChallenge, isLoading: challengeLoading } = useQuery({
    queryKey: ["daily-challenge-today"],
    queryFn: async () => {
      const today = format(new Date(), "yyyy-MM-dd");
      const { data, error } = await supabase
        .from("daily_challenges")
        .select("*")
        .eq("challenge_date", today)
        .maybeSingle();
      if (error || !data) return null;
      return data as DailyChallenge;
    },
  });

  // Fetch user's attempt for today
  const { data: userAttempt, refetch: refetchAttempt } = useQuery({
    queryKey: ["daily-challenge-attempt", user?.id, todayChallenge?.id],
    queryFn: async () => {
      if (!user || !todayChallenge) return null;
      const { data } = await supabase
        .from("daily_challenge_attempts")
        .select("*")
        .eq("user_id", user.id)
        .eq("challenge_id", todayChallenge.id)
        .maybeSingle();
      return data as ChallengeAttempt | null;
    },
    enabled: !!user && !!todayChallenge,
  });

  // Fetch past attempts
  const { data: pastAttempts } = useQuery({
    queryKey: ["daily-challenge-history", user?.id],
    queryFn: async () => {
      if (!user) return [];
      const { data } = await supabase
        .from("daily_challenge_attempts")
        .select("*, daily_challenges(challenge_date, title)")
        .eq("user_id", user.id)
        .order("completed_at", { ascending: false })
        .limit(7);
      return (data || []) as (ChallengeAttempt & { daily_challenges: { challenge_date: string; title: string } })[];
    },
    enabled: !!user,
  });

  // Fetch questions for today's challenge
  const fetchQuestionsMutation = useMutation({
    mutationFn: async (questionIds: string[]) => {
      const all: Question[] = [];
      for (let i = 0; i < questionIds.length; i += 50) {
        const { data, error } = await supabase
          .from("questions")
          .select("*")
          .in("id", questionIds.slice(i, i + 50));
        if (error) throw error;
        all.push(...(data || []));
      }
      return all;
    },
    onSuccess: (qs) => {
      setQuestions(qs);
      setAnswers({});
      setCurrentIdx(0);
      setStartTime(Date.now());
      setElapsedTime(0);
      setView("quiz");
    },
    onError: () => {
      toast({ title: "Error", description: "Failed to load challenge questions", variant: "destructive" });
    },
  });

  // Submit attempt
  const submitMutation = useMutation({
    mutationFn: async () => {
      if (!todayChallenge || !user) throw new Error("Not authenticated");
      let correct = 0, wrong = 0, skipped = 0;
      questions.forEach((q) => {
        const ans = answers[q.id];
        if (ans === null || ans === undefined) skipped++;
        else if (ans === q.correct_option_index) correct++;
        else wrong++;
      });
      const score = correct * 4 - wrong;
      const timeSeconds = Math.floor((Date.now() - startTime) / 1000);
      const payload = {
        user_id: user.id,
        challenge_id: todayChallenge.id,
        answers,
        score,
        correct_count: correct,
        wrong_count: wrong,
        unattempted_count: skipped,
        time_taken_seconds: timeSeconds,
        completed_at: new Date().toISOString(),
      };
      await supabase.from("daily_challenge_attempts").upsert(payload, { onConflict: "user_id,challenge_id" });
      return { score, correct, wrong, skipped, timeSeconds };
    },
    onSuccess: (data) => {
      setResultData(data);
      setView("result");
      refetchAttempt();
    },
  });

  const handleStart = () => {
    if (!todayChallenge || todayChallenge.question_ids.length === 0) {
      toast({ title: "No challenge today", description: "Come back later!", variant: "destructive" });
      return;
    }
    fetchQuestionsMutation.mutate(todayChallenge.question_ids);
  };

  const handleOptionSelect = (optionIndex: number) => {
    const q = questions[currentIdx];
    setAnswers((prev) => ({
      ...prev,
      [q.id]: prev[q.id] === optionIndex ? null : optionIndex,
    }));
  };

  const handleFinish = () => {
    submitMutation.mutate();
  };

  const handleReattempt = () => {
    if (todayChallenge) {
      fetchQuestionsMutation.mutate(todayChallenge.question_ids);
    }
  };

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, "0")}:${secs.toString().padStart(2, "0")}`;
  };

  const attemptedCount = Object.values(answers).filter((a) => a !== null && a !== undefined).length;

  // ===== LANDING VIEW =====
  if (view === "landing") {
    return (
      <DashboardLayout>
        <div className="p-4 lg:p-6 space-y-6 max-w-4xl">
          {/* Header */}
          <Card className="overflow-hidden border-0 shadow-lg">
            <div className="bg-gradient-to-r from-orange-500 via-amber-500 to-yellow-500 p-6 text-white">
              <div className="flex items-center gap-2 mb-2">
                <Flame className="h-5 w-5" />
                <span className="text-xs font-bold tracking-wider uppercase">Daily Challenge</span>
              </div>
              <h1 className="text-2xl lg:text-3xl font-bold">
                Today&apos;s <span className="italic">5-Question</span> Challenge
              </h1>
              <p className="text-white/90 mt-1 text-sm">
                {todayChallenge
                  ? todayChallenge.description
                  : "A fresh set of questions every day to keep your preparation on track."}
              </p>
              <div className="flex gap-3 mt-4">
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm flex items-center gap-1">
                  <Calendar className="h-3.5 w-3.5" />
                  {format(new Date(), "EEEE, MMM d")}
                </span>
                <span className="px-3 py-1 bg-white/20 rounded-full text-sm flex items-center gap-1">
                  <Timer className="h-3.5 w-3.5" />
                  No time limit
                </span>
              </div>
            </div>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className="flex gap-6">
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary">
                      {todayChallenge?.question_ids.length || 0}
                    </p>
                    <p className="text-xs text-muted-foreground">Questions</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary">
                      {todayChallenge ? (todayChallenge.question_ids.length * 4) : 0}
                    </p>
                    <p className="text-xs text-muted-foreground">Max Score</p>
                  </div>
                  <div className="text-center">
                    <p className="text-3xl font-bold text-primary">+4/-1</p>
                    <p className="text-xs text-muted-foreground">Marking</p>
                  </div>
                </div>
                <div>
                  {userAttempt ? (
                    <div className="flex flex-col items-end gap-2">
                      <Badge className="bg-green-600 hover:bg-green-600 gap-1">
                        <CheckCircle2 className="h-3 w-3" /> Completed — {userAttempt.score} pts
                      </Badge>
                      <Button onClick={handleReattempt} variant="outline" size="sm" className="gap-1">
                        <RotateCcw className="h-3.5 w-3.5" /> Reattempt
                      </Button>
                    </div>
                  ) : (
                    <Button
                      onClick={handleStart}
                      disabled={challengeLoading || !todayChallenge || fetchQuestionsMutation.isPending}
                      className="gap-2 h-12 px-6 text-base"
                    >
                      {fetchQuestionsMutation.isPending ? (
                        <Sparkles className="h-4 w-4 animate-spin" />
                      ) : (
                        <Trophy className="h-4 w-4" />
                      )}
                      Start Challenge
                    </Button>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Streak & Stats */}
          <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <Flame className="h-6 w-6 mx-auto mb-1 text-orange-500" />
                <p className="text-2xl font-bold">
                  {pastAttempts?.length || 0}
                </p>
                <p className="text-xs text-muted-foreground">Challenges Done</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <Trophy className="h-6 w-6 mx-auto mb-1 text-yellow-500" />
                <p className="text-2xl font-bold">
                  {pastAttempts && pastAttempts.length > 0
                    ? Math.max(...pastAttempts.map((a) => a.score))
                    : 0}
                </p>
                <p className="text-xs text-muted-foreground">Best Score</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <BarChart3 className="h-6 w-6 mx-auto mb-1 text-blue-500" />
                <p className="text-2xl font-bold">
                  {pastAttempts && pastAttempts.length > 0
                    ? Math.round(pastAttempts.reduce((s, a) => s + a.score, 0) / pastAttempts.length)
                    : 0}
                </p>
                <p className="text-xs text-muted-foreground">Avg Score</p>
              </CardContent>
            </Card>
          </div>

          {/* History */}
          {pastAttempts && pastAttempts.length > 0 && (
            <Card>
              <CardContent className="p-4">
                <h3 className="font-semibold mb-3 flex items-center gap-2">
                  <Calendar className="h-4 w-4 text-primary" /> Recent Challenges
                </h3>
                <div className="space-y-2">
                  {pastAttempts.slice(0, 7).map((a) => (
                    <div key={a.id} className="flex items-center justify-between p-2 rounded-lg border">
                      <div>
                        <p className="text-sm font-medium">
                          {a.daily_challenges?.title || "Daily Challenge"}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {format(new Date(a.daily_challenges?.challenge_date || a.completed_at), "MMM d, yyyy")}
                        </p>
                      </div>
                      <div className="text-right">
                        <p className="font-bold text-primary">{a.score} pts</p>
                        <p className="text-xs text-muted-foreground">
                          {a.correct_count}✓ {a.wrong_count}✗ {a.unattempted_count}○
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {!todayChallenge && !challengeLoading && (
            <Card>
              <CardContent className="p-8 text-center text-muted-foreground">
                <Sparkles className="h-10 w-10 mx-auto mb-2 opacity-50" />
                <p className="font-medium">No challenge set for today yet.</p>
                <p className="text-sm">Check back later — new challenges are posted daily!</p>
              </CardContent>
            </Card>
          )}
        </div>
      </DashboardLayout>
    );
  }

  // ===== QUIZ VIEW =====
  if (view === "quiz" && questions.length > 0) {
    const q = questions[currentIdx];
    const picked = answers[q.id];

    return (
      <DashboardLayout>
        <div className="p-3 lg:p-6 max-w-4xl mx-auto space-y-4">
          {/* Top bar */}
          <div className="flex items-center justify-between gap-2">
            <Button variant="ghost" size="sm" onClick={() => setView("landing")}>
              Exit
            </Button>
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="gap-1">
                <Timer className="h-3 w-3" /> {formatTime(elapsedTime)}
              </Badge>
              <Badge variant="secondary">
                Q {currentIdx + 1} / {questions.length}
              </Badge>
              <Badge variant="outline" className="gap-1 bg-primary/5">
                <CheckCircle2 className="h-3 w-3" /> {attemptedCount}/{questions.length}
              </Badge>
            </div>
          </div>

          {/* Progress */}
          <div className="h-2 rounded-full bg-muted overflow-hidden">
            <div
              className="h-full bg-primary transition-all duration-300"
              style={{ width: `${((currentIdx + 1) / questions.length) * 100}%` }}
            />
          </div>

          {/* Question */}
          <Card>
            <CardContent className="p-4 lg:p-6">
              <div
                className="text-base lg:text-lg leading-relaxed font-medium"
                dangerouslySetInnerHTML={{ __html: q.question_text }}
              />
              {q.images && q.images.length > 0 && (
                <div className="mt-4 space-y-2">
                  {q.images.map((img, i) => (
                    <img key={i} src={img} alt="Question" className="max-w-full rounded-lg border" />
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Options */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            {q.options.map((opt, i) => {
              const isSelected = picked === i;
              return (
                <Button
                  key={i}
                  variant={isSelected ? "default" : "outline"}
                  className="h-auto py-4 px-4 text-left justify-start text-sm whitespace-normal leading-relaxed"
                  onClick={() => handleOptionSelect(i)}
                >
                  <span className="font-bold mr-3 flex-shrink-0 w-7 h-7 rounded-full bg-primary/10 flex items-center justify-center text-xs">
                    {LETTERS[i]}
                  </span>
                  <span dangerouslySetInnerHTML={{ __html: opt }} />
                </Button>
              );
            })}
          </div>

          {/* Navigation */}
          <div className="flex items-center justify-between gap-3 pt-2">
            <Button
              variant="outline"
              disabled={currentIdx === 0}
              onClick={() => setCurrentIdx((i) => i - 1)}
              className="gap-1"
            >
              <ChevronLeft className="h-4 w-4" /> Prev
            </Button>
            {currentIdx === questions.length - 1 ? (
              <Button onClick={handleFinish} disabled={submitMutation.isPending} className="gap-1">
                <CheckCircle2 className="h-4 w-4" /> Finish
              </Button>
            ) : (
              <Button onClick={() => setCurrentIdx((i) => i + 1)} className="gap-1">
                Next <ChevronRight className="h-4 w-4" />
              </Button>
            )}
          </div>

          {/* Question grid */}
          <Card>
            <CardContent className="p-3">
              <p className="text-xs font-semibold text-muted-foreground mb-2">Jump to question</p>
              <div className="grid grid-cols-8 sm:grid-cols-12 gap-1.5">
                {questions.map((qq, i) => {
                  const done = answers[qq.id] !== null && answers[qq.id] !== undefined;
                  return (
                    <button
                      key={qq.id}
                      onClick={() => setCurrentIdx(i)}
                      className={`h-8 rounded text-xs font-semibold border transition ${
                        i === currentIdx
                          ? "bg-primary text-primary-foreground border-primary"
                          : done
                          ? "bg-primary/10 border-primary/40 text-primary"
                          : "bg-background hover:bg-muted border-border"
                      }`}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  // ===== RESULT VIEW =====
  if (view === "result" && resultData) {
    const maxScore = questions.length * 4;
    return (
      <DashboardLayout>
        <div className="p-4 lg:p-6 max-w-4xl mx-auto space-y-6">
          <Card className="overflow-hidden">
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 p-6 text-white text-center">
              <Trophy className="h-12 w-12 mx-auto mb-2" />
              <h2 className="text-2xl font-bold">Challenge Complete!</h2>
              <p className="text-white/90">Here&apos;s how you performed today</p>
            </div>
            <CardContent className="p-6 space-y-6">
              {/* Score */}
              <div className="text-center">
                <p className="text-5xl font-black text-primary">{resultData.score}</p>
                <p className="text-sm text-muted-foreground">
                  out of {maxScore} points • Time: {formatTime(resultData.timeSeconds)}
                </p>
              </div>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4">
                <div className="text-center p-4 rounded-xl bg-green-50 dark:bg-green-950/40">
                  <CheckCircle2 className="h-6 w-6 mx-auto text-green-600 mb-1" />
                  <p className="text-2xl font-bold text-green-600">{resultData.correct}</p>
                  <p className="text-xs text-muted-foreground">Correct</p>
                </div>
                <div className="text-center p-4 rounded-xl bg-red-50 dark:bg-red-950/40">
                  <XCircle className="h-6 w-6 mx-auto text-red-600 mb-1" />
                  <p className="text-2xl font-bold text-red-600">{resultData.wrong}</p>
                  <p className="text-xs text-muted-foreground">Wrong</p>
                </div>
                <div className="text-center p-4 rounded-xl bg-muted">
                  <MinusCircle className="h-6 w-6 mx-auto text-muted-foreground mb-1" />
                  <p className="text-2xl font-bold">{resultData.skipped}</p>
                  <p className="text-xs text-muted-foreground">Skipped</p>
                </div>
              </div>

              {/* Accuracy */}
              {resultData.correct + resultData.wrong > 0 && (
                <div className="text-center">
                  <p className="text-sm text-muted-foreground mb-1">
                    Accuracy: {Math.round((resultData.correct / (resultData.correct + resultData.wrong)) * 100)}%
                  </p>
                  <div className="h-3 rounded-full bg-muted overflow-hidden max-w-xs mx-auto">
                    <div
                      className="h-full bg-green-500 transition-all"
                      style={{
                        width: `${(resultData.correct / (resultData.correct + resultData.wrong)) * 100}%`,
                      }}
                    />
                  </div>
                </div>
              )}

              {/* Actions */}
              <div className="flex gap-3 justify-center">
                <Button variant="outline" onClick={() => setView("landing")}>
                  Back to Challenges
                </Button>
                <Button onClick={handleReattempt} className="gap-1">
                  <RotateCcw className="h-4 w-4" /> Try Again
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </DashboardLayout>
    );
  }

  return null;
};

export default DailyChallenge;
