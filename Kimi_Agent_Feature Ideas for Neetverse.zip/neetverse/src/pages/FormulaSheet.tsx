import { useState, useMemo } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import {
  Tabs, TabsContent, TabsList, TabsTrigger,
} from "@/components/ui/tabs";
import { DashboardLayout } from "@/components/layout/DashboardLayout";
import { formulaCategories, constants, Formula } from "@/data/formulaSheet";
import {
  Search, Atom, FlaskConical, Sigma, BookOpen, Variable,
  ArrowRight, Copy, CheckCircle2, Hash
} from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const FormulaSheet = () => {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [activeSubject, setActiveSubject] = useState("Physics");
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [expandedFormula, setExpandedFormula] = useState<string | null>(null);

  const filteredCategories = useMemo(() => {
    return formulaCategories
      .filter((cat) => cat.subject === activeSubject)
      .map((cat) => ({
        ...cat,
        formulas: cat.formulas.filter((f) => {
          if (!search.trim()) return true;
          const term = search.toLowerCase();
          return (
            f.name.toLowerCase().includes(term) ||
            f.formula.toLowerCase().includes(term) ||
            f.chapter.toLowerCase().includes(term) ||
            f.description.toLowerCase().includes(term)
          );
        }),
      }))
      .filter((cat) => cat.formulas.length > 0);
  }, [activeSubject, search]);

  const allMatchingFormulas = useMemo(() => {
    return filteredCategories.flatMap((cat) => cat.formulas);
  }, [filteredCategories]);

  const copyFormula = (formula: Formula) => {
    navigator.clipboard.writeText(`${formula.name}: ${formula.formula}`).then(() => {
      setCopiedId(formula.id);
      toast({ title: "Copied to clipboard!", duration: 1500 });
      setTimeout(() => setCopiedId(null), 2000);
    });
  };

  return (
    <DashboardLayout>
      <div className="p-4 lg:p-6 space-y-6 max-w-5xl">
        {/* Header */}
        <Card className="overflow-hidden border-0 shadow-lg">
          <div className="bg-gradient-to-r from-violet-600 via-purple-600 to-indigo-600 p-6 text-white">
            <div className="flex items-center gap-2 mb-2">
              <Sigma className="h-5 w-5" />
              <span className="text-xs font-bold tracking-wider uppercase">Quick Reference</span>
            </div>
            <h1 className="text-2xl lg:text-3xl font-bold">
              Formula <span className="italic">Sheet</span>
            </h1>
            <p className="text-white/90 mt-1 text-sm">
              {allMatchingFormulas.length} formulas for Physics & Chemistry — searchable and copyable
            </p>
          </div>
          <CardContent className="p-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search formula name, equation, chapter..."
                className="pl-10"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </CardContent>
        </Card>

        {/* Subject Tabs */}
        <Tabs value={activeSubject} onValueChange={setActiveSubject}>
          <TabsList className="grid w-full grid-cols-2 max-w-xs">
            <TabsTrigger value="Physics" className="gap-2">
              <Atom className="h-4 w-4" /> Physics
            </TabsTrigger>
            <TabsTrigger value="Chemistry" className="gap-2">
              <FlaskConical className="h-4 w-4" /> Chemistry
            </TabsTrigger>
          </TabsList>
        </Tabs>

        {/* Constants (shown when no search) */}
        {!search.trim() && (
          <Card>
            <CardContent className="p-4">
              <h3 className="text-sm font-semibold mb-3 flex items-center gap-2">
                <Hash className="h-4 w-4 text-primary" /> Important Constants
              </h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-2">
                {constants.slice(0, 12).map((c, i) => (
                  <div
                    key={i}
                    className="p-2.5 rounded-lg bg-muted/50 border border-border text-center"
                  >
                    <p className="text-xs text-muted-foreground leading-tight">{c.name}</p>
                    <p className="text-sm font-bold font-mono mt-0.5">{c.value}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Formula Categories */}
        {filteredCategories.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-muted-foreground">
              <Search className="h-10 w-10 mx-auto mb-2 opacity-40" />
              <p>No formulas match your search.</p>
            </CardContent>
          </Card>
        ) : (
          <div className="space-y-6">
            {filteredCategories.map((category) => (
              <div key={category.id}>
                <h3 className="text-sm font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-2">
                  <BookOpen className="h-4 w-4" /> {category.name}
                  <Badge variant="outline" className="text-[10px]">{category.formulas.length}</Badge>
                </h3>
                <div className="grid grid-cols-1 gap-2">
                  {category.formulas.map((formula) => {
                    const isExpanded = expandedFormula === formula.id;
                    return (
                      <Card
                        key={formula.id}
                        className={`transition-all cursor-pointer hover:border-primary/30 ${
                          isExpanded ? "ring-1 ring-primary/30" : ""
                        }`}
                        onClick={() => setExpandedFormula(isExpanded ? null : formula.id)}
                      >
                        <CardContent className="p-4">
                          <div className="flex items-start justify-between gap-3">
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-2 flex-wrap">
                                <p className="font-semibold text-sm">{formula.name}</p>
                                <Badge variant="outline" className="text-[10px]">{formula.chapter}</Badge>
                              </div>
                              <p className="text-lg sm:text-xl font-mono font-bold text-primary mt-1.5">
                                {formula.formula}
                              </p>
                            </div>
                            <Button
                              variant="ghost"
                              size="icon"
                              className="h-8 w-8 flex-shrink-0"
                              onClick={(e) => {
                                e.stopPropagation();
                                copyFormula(formula);
                              }}
                            >
                              {copiedId === formula.id ? (
                                <CheckCircle2 className="h-4 w-4 text-green-500" />
                              ) : (
                                <Copy className="h-4 w-4 text-muted-foreground" />
                              )}
                            </Button>
                          </div>

                          {/* Expanded details */}
                          {isExpanded && (
                            <div className="mt-4 pt-3 border-t space-y-3">
                              <p className="text-sm text-muted-foreground">{formula.description}</p>
                              <div className="space-y-1.5">
                                <p className="text-xs font-semibold text-muted-foreground flex items-center gap-1">
                                  <Variable className="h-3 w-3" /> Variables
                                </p>
                                <div className="grid grid-cols-1 sm:grid-cols-2 gap-1.5">
                                  {formula.variables.map((v, i) => (
                                    <div
                                      key={i}
                                      className="flex items-center gap-2 text-sm p-2 rounded bg-muted/50"
                                    >
                                      <span className="font-mono font-bold text-primary text-xs min-w-[30px]">
                                        {v.symbol}
                                      </span>
                                      <ArrowRight className="h-3 w-3 text-muted-foreground flex-shrink-0" />
                                      <span className="text-muted-foreground text-xs">{v.meaning}</span>
                                    </div>
                                  ))}
                                </div>
                              </div>
                            </div>
                          )}
                        </CardContent>
                      </Card>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default FormulaSheet;
