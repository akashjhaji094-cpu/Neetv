-- Daily Challenge entries (admin sets questions, users attempt them)
CREATE TABLE IF NOT EXISTS daily_challenges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  challenge_date date NOT NULL UNIQUE DEFAULT CURRENT_DATE,
  question_ids uuid[] NOT NULL DEFAULT '{}',
  title text DEFAULT 'Daily Challenge',
  description text DEFAULT 'Test yourself with today''s curated questions!',
  created_at timestamptz DEFAULT now()
);

-- User attempts at daily challenges
CREATE TABLE IF NOT EXISTS daily_challenge_attempts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  challenge_id uuid NOT NULL REFERENCES daily_challenges(id) ON DELETE CASCADE,
  answers jsonb DEFAULT '{}',
  score integer DEFAULT 0,
  correct_count integer DEFAULT 0,
  wrong_count integer DEFAULT 0,
  unattempted_count integer DEFAULT 0,
  time_taken_seconds integer DEFAULT 0,
  completed_at timestamptz DEFAULT now(),
  UNIQUE(user_id, challenge_id)
);

-- Indexes
CREATE INDEX IF NOT EXISTS idx_daily_challenges_date ON daily_challenges(challenge_date);
CREATE INDEX IF NOT EXISTS idx_daily_challenge_attempts_user ON daily_challenge_attempts(user_id);
CREATE INDEX IF NOT EXISTS idx_daily_challenge_attempts_challenge ON daily_challenge_attempts(challenge_id);

-- RLS
ALTER TABLE daily_challenges ENABLE ROW LEVEL SECURITY;
ALTER TABLE daily_challenge_attempts ENABLE ROW LEVEL SECURITY;

-- Everyone can read daily challenges
CREATE POLICY "Daily challenges are readable by all"
  ON daily_challenges FOR SELECT
  TO authenticated, anon
  USING (true);

-- Admin insert only (handled via admin check in app)
CREATE POLICY "Admin can insert daily challenges"
  ON daily_challenges FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- Users manage own attempts
CREATE POLICY "Users can view own challenge attempts"
  ON daily_challenge_attempts FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own challenge attempts"
  ON daily_challenge_attempts FOR INSERT
  WITH CHECK (auth.uid() = user_id);
